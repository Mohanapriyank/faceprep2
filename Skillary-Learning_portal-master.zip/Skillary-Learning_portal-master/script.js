document.querySelectorAll('.btn-primary').forEach(button => {
    button.addEventListener('click', function() {
      window.location.href = 'enroll.html';
    });
  });